<h3
    <?php echo e($attributes->class(['fi-no-notification-title text-sm font-medium text-gray-950 dark:text-white'])); ?>

>
    <?php echo e($slot); ?>

</h3>
<?php /**PATH /Users/antonanton/projects/verstkaTailandSluhi/reactProject/Архив 2/backend/vendor/filament/notifications/resources/views/components/title.blade.php ENDPATH**/ ?>