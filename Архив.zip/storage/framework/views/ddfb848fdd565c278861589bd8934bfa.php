<?php if (isset($component)) { $__componentOriginal166a02a7c5ef5a9331faf66fa665c256 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'filament-panels::components.page.index','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('filament-panels::page'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        .fi-main { background: #0d0d0d !important; }
        #support-chat-wrap * { box-sizing: border-box; }
        #support-chat-wrap ::-webkit-scrollbar { width: 4px; }
        #support-chat-wrap ::-webkit-scrollbar-track { background: transparent; }
        #support-chat-wrap ::-webkit-scrollbar-thumb { background: #333; border-radius: 99px; }
        #support-chat-wrap textarea:focus,
        #support-chat-wrap textarea:focus-visible { outline: none !important; box-shadow: none !important; }

        @keyframes msgIn {
            from { opacity: 0; transform: translateY(10px) scale(0.96); }
            to   { opacity: 1; transform: translateY(0)   scale(1);    }
        }
        .msg-new { animation: msgIn 0.28s cubic-bezier(0.34, 1.56, 0.64, 1) both; }
    </style>

    <div
        id="support-chat-wrap"
        class="flex rounded-2xl overflow-hidden"
        style="height: calc(100vh - 9rem); background: #111; border: 1px solid #222;"
    >
        
        <div class="flex flex-col shrink-0" style="width:300px; border-right:1px solid #1e1e1e; background:#0d0d0d;">

            
            <div style="padding:16px 14px 12px; border-bottom:1px solid #1e1e1e;">
                <p style="font-size:11px;font-weight:600;letter-spacing:.08em;color:#555;text-transform:uppercase;margin-bottom:10px;">Чаты</p>
                <div style="position:relative;">
                    <svg style="position:absolute;left:10px;top:50%;transform:translateY(-50%);color:#444;width:14px;height:14px;" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" d="m21 21-4.35-4.35M17 11A6 6 0 1 1 5 11a6 6 0 0 1 12 0Z"/>
                    </svg>
                    <input
                        wire:model.live.debounce.300ms="search"
                        type="text"
                        placeholder="Поиск..."
                        style="width:100%;padding:7px 10px 7px 32px;font-size:13px;background:#1a1a1a;border:1px solid #2a2a2a;border-radius:10px;color:#ddd;transition:border-color .15s;"
                        onfocus="this.style.borderColor='#444'" onblur="this.style.borderColor='#2a2a2a'"
                    />
                </div>
            </div>

            
            <div style="flex:1;overflow-y:auto;">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->getChats(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $client     = $chat->participants->firstWhere(fn($p) => $p->user && ! in_array($p->user->role->value, ['admin','support']))?->user;
                        $lastMsg    = $chat->messages->first();
                        $initial    = strtoupper(substr($client?->first_name ?? 'U', 0, 1));
                        $fullName   = trim(($client?->first_name ?? '').' '.($client?->last_name ?? '')) ?: 'Пользователь';
                        $isSelected = $selectedChatId === $chat->id;
                    ?>
                    <button
                        wire:click="selectChat(<?php echo e($chat->id); ?>)"
                        style="width:100%;display:flex;align-items:center;gap:10px;padding:11px 14px;text-align:left;border:none;cursor:pointer;transition:background .12s;
                               background:<?php echo e($isSelected ? '#1a1a1a' : 'transparent'); ?>;
                               border-left:2px solid <?php echo e($isSelected ? '#E2319B' : 'transparent'); ?>;"
                        onmouseenter="if(!<?php echo e($isSelected ? 'true' : 'false'); ?>)this.style.background='#161616'"
                        onmouseleave="if(!<?php echo e($isSelected ? 'true' : 'false'); ?>)this.style.background='transparent'"
                    >
                        <div style="width:38px;height:38px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;color:#fff;flex-shrink:0;overflow:hidden;
                                    background:<?php echo e($isSelected ? '#E2319B' : '#2a2a2a'); ?>;">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($client?->photo_url): ?>
                                <img src="<?php echo e($client->photo_url); ?>" alt="" style="width:100%;height:100%;object-fit:cover;" onerror="this.style.display='none';this.parentElement.insertAdjacentText('beforeend','<?php echo e($initial); ?>')">
                            <?php else: ?>
                                <?php echo e($initial); ?>

                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                        <div style="flex:1;min-width:0;">
                            <div style="display:flex;align-items:center;justify-content:space-between;gap:4px;">
                                <span style="font-size:13px;font-weight:600;color:<?php echo e($isSelected ? '#fff' : '#ccc'); ?>;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                    <?php echo e($fullName); ?>

                                </span>
                                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lastMsg): ?>
                                    <span style="font-size:10px;color:#444;flex-shrink:0;"><?php echo e($lastMsg->created_at->diffForHumans(short: true)); ?></span>
                                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            </div>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($client?->username): ?>
                                <div style="font-size:11px;color:#555;margin-top:1px;"><?php echo e($client->username); ?></div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($lastMsg): ?>
                                <div style="font-size:12px;color:#555;margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                                    <?php echo e(Str::limit($lastMsg->body, 34)); ?>

                                </div>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div style="display:flex;flex-direction:column;align-items:center;justify-content:center;padding:48px 16px;text-align:center;">
                        <svg style="width:32px;height:32px;color:#333;margin-bottom:8px;" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M8.625 12a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H8.25m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0H12m4.125 0a.375.375 0 1 1-.75 0 .375.375 0 0 1 .75 0Zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 0 1-2.555-.337A5.972 5.972 0 0 1 5.41 20.97a5.969 5.969 0 0 1-.474-.065 4.48 4.48 0 0 0 .978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25Z"/>
                        </svg>
                        <p style="font-size:13px;color:#444;">Нет активных чатов</p>
                    </div>
                <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>

        
        <div style="flex:1;display:flex;flex-direction:column;min-width:0;background:#111;">
            <?php $selectedChat = $this->getSelectedChat(); ?>

            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($selectedChatId && $selectedChat): ?>
                <?php
                    $chatClient = $selectedChat->participants->firstWhere(fn($p) => $p->user && ! in_array($p->user->role->value, ['admin','support']))?->user;
                    $clientName = trim(($chatClient?->first_name ?? '').' '.($chatClient?->last_name ?? '')) ?: 'Пользователь';
                ?>

                
                <div style="display:flex;align-items:center;gap:12px;padding:12px 20px;border-bottom:1px solid #1e1e1e;flex-shrink:0;">
                    <?php $headerInitial = strtoupper(substr($chatClient?->first_name ?? 'U', 0, 1)); ?>
                    <div style="width:36px;height:36px;border-radius:50%;background:#E2319B;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#fff;flex-shrink:0;overflow:hidden;">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($chatClient?->photo_url): ?>
                            <img src="<?php echo e($chatClient->photo_url); ?>" alt="" style="width:100%;height:100%;object-fit:cover;" onerror="this.style.display='none';this.parentElement.insertAdjacentText('beforeend','<?php echo e($headerInitial); ?>')">
                        <?php else: ?>
                            <?php echo e($headerInitial); ?>

                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div>
                        <div style="font-size:14px;font-weight:600;color:#eee;"><?php echo e($clientName); ?></div>
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($chatClient?->username): ?>
                            <div style="font-size:12px;color:#555;"><?php echo e($chatClient->username); ?></div>
                        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                    </div>
                    <div style="margin-left:auto;">
                        <span style="font-size:11px;color:#555;background:#1a1a1a;border:1px solid #2a2a2a;border-radius:99px;padding:3px 10px;">Поддержка</span>
                    </div>
                </div>

                
                <div id="msg-list" data-chat-id="<?php echo e($selectedChatId); ?>" style="flex:1;overflow-y:auto;padding:20px;display:flex;flex-direction:column;gap:4px;">
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__empty_1 = true; $__currentLoopData = $this->getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <?php $isSupport = in_array($message->sender?->role->value, ['admin','support']); ?>
                        <div
                            data-msg-id="<?php echo e($message->id); ?>"
                            style="display:flex;justify-content:<?php echo e($isSupport ? 'flex-end' : 'flex-start'); ?>;margin-bottom:2px;"
                        >
                            <div style="max-width:62%;display:flex;flex-direction:column;align-items:<?php echo e($isSupport ? 'flex-end' : 'flex-start'); ?>;gap:3px;">
                                <div style="padding:10px 14px;border-radius:18px;font-size:14px;line-height:1.5;word-break:break-word;
                                            <?php echo e($isSupport
                                                ? 'background:#E2319B;color:#fff;border-bottom-right-radius:4px;'
                                                : 'background:#1e1e1e;color:#ccc;border-bottom-left-radius:4px;'); ?>">
                                    <?php echo e($message->body); ?>

                                </div>
                                <span style="font-size:10px;color:#444;padding:0 4px;"><?php echo e($message->created_at->format('H:i')); ?></span>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <div style="flex:1;display:flex;align-items:center;justify-content:center;">
                            <p style="font-size:13px;color:#444;">Нет сообщений</p>
                        </div>
                    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                </div>

                
                <div style="padding:12px 16px 16px;border-top:1px solid #1e1e1e;flex-shrink:0;">
                    <div style="display:flex;align-items:flex-end;gap:10px;">
                        <div style="flex:1;background:#1a1a1a;border:1px solid #2a2a2a;border-radius:14px;padding:10px 14px;">
                            <textarea
                                wire:model.defer="newMessage"
                                wire:keydown.enter.prevent="sendReply"
                                rows="1"
                                placeholder="Написать ответ..."
                                style="outline:none;width:100%;background:transparent;font-size:14px;color:#ddd;border:none;resize:none;max-height:100px;overflow-y:auto;line-height:1.5;"
                                oninput="this.style.height='auto';this.style.height=Math.min(this.scrollHeight,100)+'px'"
                            ></textarea>
                        </div>
                        <button
                            wire:click="sendReply"
                            style="width:40px;height:40px;border-radius:50%;background:#E2319B;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;flex-shrink:0;transition:background .15s,transform .1s;"
                            onmouseenter="this.style.background='#c9197f'" onmouseleave="this.style.background='#E2319B'"
                            onmousedown="this.style.transform='scale(.9)'" onmouseup="this.style.transform='scale(1)'"
                        >
                            <svg width="16" height="16" fill="none" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" stroke="#fff" d="M6 12 3.269 3.125A59.769 59.769 0 0 1 21.485 12 59.768 59.768 0 0 1 3.27 20.875L5.999 12Zm0 0h7.5"/>
                            </svg>
                        </button>
                    </div>
                </div>

            <?php else: ?>
                
                <div style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:10px;text-align:center;padding:32px;">
                    <div style="width:56px;height:56px;border-radius:50%;background:#1a1a1a;border:1px solid #2a2a2a;display:flex;align-items:center;justify-content:center;">
                        <svg style="width:24px;height:24px;color:#444;" fill="none" stroke="currentColor" stroke-width="1.5" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M20.25 8.511c.884.284 1.5 1.128 1.5 2.097v4.286c0 1.136-.847 2.1-1.98 2.193-.34.027-.68.052-1.02.072v3.091l-3-3c-1.354 0-2.694-.055-4.02-.163a2.115 2.115 0 0 1-.825-.242m9.345-8.334a2.126 2.126 0 0 0-.476-.095 48.64 48.64 0 0 0-8.048 0c-1.131.094-1.976 1.057-1.976 2.192v4.286c0 .837.46 1.58 1.155 1.951m9.345-8.334V6.637c0-1.621-1.152-3.026-2.76-3.235A48.455 48.455 0 0 0 11.25 3c-2.115 0-4.198.137-6.24.402-1.608.209-2.76 1.614-2.76 3.235v6.226c0 1.621 1.152 3.026 2.76 3.235.577.075 1.157.14 1.74.194V21l4.155-4.155"/>
                        </svg>
                    </div>
                    <p style="font-size:13px;color:#444;">Выберите чат слева</p>
                </div>
            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>

    <script src="https://js.pusher.com/8.2.0/pusher.min.js"></script>
    <script>
    (function () {
        let pusher       = null;
        let channel      = null;
        let activeChatId = null;
        let skipAnim     = false;

        function getPusher() {
            if (!pusher) {
                pusher = new Pusher('<?php echo e(config("broadcasting.connections.reverb.key")); ?>', {
                    wsHost:            '<?php echo e(config("broadcasting.connections.reverb.options.host", "127.0.0.1")); ?>',
                    wsPort:            <?php echo e((int) config("broadcasting.connections.reverb.options.port", 8080)); ?>,
                    wssPort:           <?php echo e((int) config("broadcasting.connections.reverb.options.port", 8080)); ?>,
                    forceTLS:          <?php echo e(config("broadcasting.connections.reverb.options.scheme", "http") === "https" ? "true" : "false"); ?>,
                    cluster:           'mt1',
                    enabledTransports: ['ws', 'wss'],
                    authEndpoint:      '/admin/broadcasting/auth',
                    auth: {
                        headers: {
                            'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')?.content ?? '',
                        },
                    },
                });
            }
            return pusher;
        }

        function subscribeToChat(chatId) {
            const p = getPusher();
            if (channel) { p.unsubscribe(channel.name); channel = null; }
            if (!chatId) return;
            activeChatId = chatId;
            channel = p.subscribe('private-chats.' + chatId);
            channel.bind('message.sent', function () {
                Livewire.dispatch('new-message-received');
            });
        }

        function scrollBottom() {
            const list = document.getElementById('msg-list');
            if (list) list.scrollTop = list.scrollHeight;
        }

        // Mark all current messages as seen (no animation)
        function markAllSeen() {
            document.querySelectorAll('[data-msg-id]').forEach(function (el) {
                el.setAttribute('data-animated', '1');
            });
        }

        // Animate only messages that haven't been animated yet
        function animateNewMessages() {
            if (skipAnim) { markAllSeen(); skipAnim = false; return; }
            document.querySelectorAll('[data-msg-id]:not([data-animated])').forEach(function (el) {
                el.setAttribute('data-animated', '1');
                el.classList.add('msg-new');
            });
        }

        function syncChatSubscription() {
            const list   = document.getElementById('msg-list');
            const chatId = list ? list.dataset.chatId : null;
            if (chatId && chatId !== String(activeChatId)) {
                skipAnim = true; // initial load of this chat — don't animate existing messages
                subscribeToChat(chatId);
            }
        }

        document.addEventListener('livewire:init', function () {
            syncChatSubscription();
            markAllSeen(); // page load — mark everything as seen
            scrollBottom();
        });

        document.addEventListener('livewire:update', function () {
            syncChatSubscription();
            scrollBottom();
            requestAnimationFrame(animateNewMessages);
        });
    })();
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $attributes = $__attributesOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__attributesOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256)): ?>
<?php $component = $__componentOriginal166a02a7c5ef5a9331faf66fa665c256; ?>
<?php unset($__componentOriginal166a02a7c5ef5a9331faf66fa665c256); ?>
<?php endif; ?>
<?php /**PATH /Users/antonanton/projects/verstkaTailandSluhi/reactProject/Архив 2/backend/resources/views/filament/pages/support-chats.blade.php ENDPATH**/ ?>